<template>
  <div>
    成绩单
  </div>
</template>

<script>
  export default {
    name: "index"
  }
</script>

<style scoped>

</style>
