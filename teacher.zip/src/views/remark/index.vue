<template>
  <div>
    录入成绩单
  </div>
</template>

<script>
  export default {
    name: "index"
  }
</script>

<style scoped>

</style>
