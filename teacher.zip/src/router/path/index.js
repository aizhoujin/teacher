export default [{
  path: '/login',
  name: 'login',
  component: () => import('@/page/login/index.vue')
}]
